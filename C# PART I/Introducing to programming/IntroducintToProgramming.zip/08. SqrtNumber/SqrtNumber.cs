﻿/*
Task 08.
Create a console application that calculates and prints the square of the number 12345.
*/
using System;

class SqrtNumber
{
    static void Main()
    {
        int taskNumber = 12345;
        Console.WriteLine("The square of " + taskNumber + " is: " + Math.Sqrt(taskNumber));
    }
}

