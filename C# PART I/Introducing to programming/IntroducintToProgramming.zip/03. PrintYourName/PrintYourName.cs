﻿/*
Task 03.
Modify the application to print your name. (see application 02. HelloCSharp)
*/
using System;

class PrintYourName
{
    static void Main()
    {
        string myName = "Hello, Evdoki"; //This is not my real name
        Console.WriteLine(myName);
    }
}
