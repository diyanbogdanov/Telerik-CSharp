﻿/*
Task 06.
Create console application that prints your first and last name.
*/
using System;

class PrintFirstAndLastName
{
    static void Main()
    {
        string firstName = "Mihael"; //This is not my real first name
        string lastNmae = "Fernandes"; //And this is not my real last name
        Console.WriteLine(firstName + " " + lastNmae);
    }
}

