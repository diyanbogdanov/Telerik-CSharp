﻿/*
Task 02.
Create, compile and run a “Hello C#” console application.
*/
using System;

class HelloCSharp
{
    static void Main()
    {
        string helloCSharp = "Hello C#";
        Console.WriteLine(helloCSharp);
    }
}

