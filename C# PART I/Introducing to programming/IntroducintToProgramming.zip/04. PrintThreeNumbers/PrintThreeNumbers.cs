﻿/*
Task 04.
Write a program to print the numbers 1, 101 and 1001.
*/
using System;

class PrintThreeNumbers
{
    static void Main()
    {
        string threeNumbers = "1\n101\n1001";
        Console.WriteLine(threeNumbers);
    }
}

