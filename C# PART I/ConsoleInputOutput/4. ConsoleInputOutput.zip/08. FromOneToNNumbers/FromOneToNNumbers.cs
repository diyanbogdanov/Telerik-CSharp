﻿/*
Task 08.
Write a program that reads an integer number n from the console and prints all the numbers in the interval [1..n], each on a single line.
*/
using System;

class FromOneToNNumbers
{
    static void Main()
    {
        Console.Title = "From One to N numbers on single line";//Title
        Console.Write("Please write a number: ");//Read number from console
        int number = int.Parse(Console.ReadLine());
        for (int i = 1; i <= number; i++)
        {
            Console.Write("{0},",i);
        }
        Console.WriteLine();//Empty line
    }
}
