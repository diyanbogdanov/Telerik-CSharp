printMsg("Before declaration");
var printMsg = function (msg){
	console.log("Message: " + msg);
}
printMsg("After declaration");