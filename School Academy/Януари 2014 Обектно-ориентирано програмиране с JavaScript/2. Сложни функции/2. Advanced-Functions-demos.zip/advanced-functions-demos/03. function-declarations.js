printMsg("Before declaration");
function printMsg(msg){
	console.log("Message: " + msg);
}
printMsg("After declaration");