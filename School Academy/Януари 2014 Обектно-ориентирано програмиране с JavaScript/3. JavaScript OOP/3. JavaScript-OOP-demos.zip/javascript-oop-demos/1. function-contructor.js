function Person(name,age){
  console.log("Name: " + name + ", Age: " + age);
}

var personGosho = new Person("Georgi",23);

var personMaria = new Person("Maria",18);
